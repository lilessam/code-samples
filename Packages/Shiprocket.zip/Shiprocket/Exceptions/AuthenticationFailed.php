<?php

namespace App\Shiprocket\Exceptions;

class AuthenticationFailed extends \Exception
{
    //
}
